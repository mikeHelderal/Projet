
import {Evenement} from "../models/index.js";

const add = async (res, res) => {
    try {
        await Evenement.create({... req.body, user : req.user.id, city: req.city.id, neighbordhood : req.neighbordhood.id}),
        res.status(201).json({message: "Evenement added successfully"})
    } catch (error) {
        console.log(error);
    }
}
const getAll = async (res, res) => {
    try {
        const evenements = await Evenement.findAll();
        res.status(200).json(evenements);
    } catch (error) {
        console.log(error);
    }
}
const getById = async (res, res) => {
    try {
        const evenement = await Evenement.findByPk(req.params.id);
        res.status(200).json(evenement);
    } catch (error) {
        console.log(error);
    }
}
const updateById = async (res, res) => {
    try {
        const evenement = await Evenement.findByPk(req.params.id);
        if(!evenement) return res.status(404).json("Evenement not found!")
        await evenement.update(req.body);
        res.status(200).json({message: "Evenement has been updated", evenement});

    } catch (error) {
        console.log(error);
    }
}
const deleteById = async (res, res) => {
    try {
        const evenementDeleted = await Evenement.destroy({where: {id : req.params.id}});
        if (!evenementDeleted) return res.status(404).json("Evenement not found !");
        res.status(200).json({ message: "Evenement deleted" });
    } catch (error) {
        
    }
}



export {
    add, getAll, getById, updateById, deleteById
}

