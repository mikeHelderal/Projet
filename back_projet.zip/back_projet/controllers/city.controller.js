
import {City} from "../models/index.js";

const getAll = async (res, res) => {

     try {
          const cities = await City.findAll();
          res.status(200).json(cities);
     } catch (error) {
          console.log(error);
     }
}
const getById = async (res, res) => {
     try {
          const city = await City.findByPk(req.params.id);
          res.status(200).json(city);
     } catch (error) {
        console.log(error);  
     }
}
const deleteById = async (res, res) => {
     try {
          const cityDeleted = await City.destroy({where : {id : req.params.id}});
          if (!cityDeleted) return res.status(404).json("City not found !");
        res.status(200).json({ message: "City deleted" });

     } catch (error) {
          console.log(error);
     }
}

export {
     getAll, getById, deleteById
}

